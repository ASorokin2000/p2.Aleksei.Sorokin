let capture;
let weather;
let weath_part_cloud;
let weath_cloud;
let weath_rain;
let weath_night;
let news;
let messages;
let social;
let twitter;
let instagram
let facebook;
let calendar;
let health_pic;
let health;
let exercise;
let stood;
let steps;
let clos;
let event = 0;
let cal_day;

function preload() {

  weather = loadTable('assets/weather.csv', 'csv');
  news = loadTable('assets/news.csv', 'csv');
  messages = loadTable('assets/messages.csv', 'csv');
  social = loadTable('assets/social.csv', 'csv');
  calendar = loadTable('assets/calendar.csv', 'csv');
  health = loadTable('assets/health.csv', 'csv');
  weath_part_cloud = loadImage('assets/partly_cloudy.png');
  weath_cloud = loadImage('assets/cloudy.png');
  weath_rain = loadImage('assets/rain.png');
  weath_night = loadImage('assets/night.png');
  twitter = loadImage('assets/twitter.jpg');
  facebook = loadImage('assets/facebook.png');
  instagram = loadImage('assets/instagram.png');
  health_pic = loadImage('assets/health.png');
  exercise = loadImage('assets/exercise.jpg');
  stood = loadImage('assets/stood.png');
  steps = loadImage('assets/steps.png');
  clos = loadImage('assets/close.png');
}


function setup() {
  createCanvas(1200, 550);
 capture = createCapture(VIDEO);
 capture.hide();
  
}


function draw() {
  image(capture, 0, 0, width, width * capture.height / capture.width);

  let t_day = day();
  let t_month = month();
  let t_year = year();
  let t_hour = hour();
  let t_minute = minute();
  let t_noon = " AM";
  let temprature;
    
    

  if (t_minute < 10)
    t_minute = "0"+t_minute;

  if (t_hour > 12)
  {
    t_noon = " PM"; 
    t_hour = t_hour - 12;
  }
  if (t_hour == 0)
    t_hour = 12;

   
  fill(255, 255, 255);
  textSize(20);                
  text(t_hour+":"+t_minute + t_noon, 1100, 505);
  text(t_month+"/"+t_day+"/"+t_year,1085, 535);

  temprature = get_temp();
  text(temprature+"°F",1030, 535);
    
  draw_weath_icon();   
  draw_news();
    
  draw_messages();
  draw_social();
  draw_calendar(); 
   
  draw_health();    
  if (event == 1)
  openMessage();
  else if (event == 2)
  openSocial();
  else if (event == 3)
  openCalendar();
    
    
  
}


function draw_health()
{
    let rows = health.getRowCount();
    let d;
    
    for (let r = 0; r < rows; r++)
        if (health.getNum(r,0) == day())   
     {
         d = r;
         break;
     }
    
    image(health_pic, 150, 10, 50, 50);
    textSize(20);
    text("Sleep", 30, 95);
    text("Weight", 25, 150);
    textSize(14);
    text( ~~(health.getNum(d,1) / 60) +"hr " + health.getNum(d,1) % 60 + "min", 120,95);
    let sleep_dif = health.getNum(d,1) - health.getNum(d-1,1);
    let sign = '+';
    if (sleep_dif < 0)
        {
            sign = '-';
            sleep_dif *= -1;
        }
    if (sleep_dif > 60)
        text(sign + ~~(sleep_dif / 60) +"hr " + sleep_dif % 60 + "min", 200,95);
    else text(sign + sleep_dif + "min", 200,95);
    textSize(12);
    text ("light", 260, 80);
    text ("deep", 260, 110);
    text (health.getNum(d,2) +"%", 307, 80);
    text ((100-health.getNum(d,2)) +"%", 307, 110);
    
    textSize(14);
    text( health.getNum(d,3) + "lbs", 120,150);
    let weight_dif = round(health.getNum(d,3) - health.getNum(d-1,3), 1);
    sign = '+';
    if (weight_dif < 0)
        {
            sign = '-';
            weight_dif *= -1;
        }
    text(sign + weight_dif + "lbs", 200,150);
    
    text ("M", 260, 140);
    fill (255, 240, 0);
    circle(280, 135, 10);
    fill (55, 40, 0);
    circle(280, 155, 10);
    fill (255, 255, 255);
    text ("M", 260, 160);
    textSize(12);
    text(health.getNum(d,4) + "min", 305,135);
    text(health.getNum(d,5) + "min", 305,165);
    textSize(14);
    image(steps, 30, 185, 50, 50);
    image(stood, 120, 185, 50, 50);
    image(exercise, 240, 185, 50, 50);
    text (health.getNum(d,6), 35, 270);
    text (~~(health.getNum(d,7) / 60) +"hr " + health.getNum(d,7) % 60 + "min", 120, 270);
    if (health.getNum(d,8) > 60)
        text( ~~(health.getNum(d,8) / 60) +"hr " + health.getNum(d,8) % 60 + "min", 245,270);
    else text(health.getNum(d,8) + "min", 250,270);
    
    let step_dif = health.getNum(d,6) - health.getNum(d-1,6);
    sign = '+';
    if (step_dif < 0)
        {
            sign = '-';
            step_dif *= -1;
        }
    text(sign+step_dif, 35, 300);
    let stood_dif = health.getNum(d,7) - health.getNum(d-1,7);
    sign = '+';
    if (stood_dif < 0)
        {
            sign = '-';
            stood_dif *= -1;
        }
    if (stood_dif > 60)
        text( sign + (~~(stood_dif / 60)) +"hr " + stood_dif % 60 + "min", 120,300);
    else text (sign+ stood_dif + "min", 120, 300);
    
    let exercise_dif = health.getNum(d,8) - health.getNum(d-1,8);
    sign = '+';
    if (exercise_dif < 0)
        {
            sign = '-';
            exercise_dif *= -1;
        }
    if (exercise_dif > 60)
        text( sign + (~~(exercise_dif / 60)) +"hr " + exercise_dif % 60 + "min", 245,300);
    else text (sign+ exercise_dif + "min", 250, 300);
    
    // draw grid
    stroke(0, 0, 255);
    line(5, 5, 350, 5);
    line(5, 5, 5, 320);
    line(350, 320, 5, 320);
    line(350, 320, 350, 5);
    //horizontal
    line(5, 280, 350, 280);
    line(5, 250, 350, 250);
    line(5, 175, 350, 175);
    line(5, 65, 350, 65);
    line(5, 120, 350, 120);
    line(250, 145, 350, 145);
    line(250, 90, 350, 90);
    //vertical
    line(100, 320, 100, 65);
    line(195, 320, 195, 65);
    line(250, 175, 250, 65);
    line(295, 175, 295, 65);
}

function draw_calendar()
{
    let rows = calendar.getRowCount();
    let t_noon_1 = " AM";
    let t_noon_2 = " AM";
    let trans;
    let row = [];
    textSize(20); 
    fill(255,255,255);
    for (let r = 0; r < rows; r++)
        if (calendar.getNum(r,0) == day() && ( calendar.getNum(r,1) > hour() || calendar.getNum(r,1) - 3 < hour()  ) )   
     {
         cal_day = r;
         trans = calendar.getRow(r);
         break;
     }
    
   row[0] = trans.getNum(0);
    row[1] = trans.getNum(1);
 row[2] = trans.getNum(2);
    row[3] = trans.getNum(3);
    row[4] = trans.getNum(4);
 row[5] = trans.getString(5);
    row[6] = trans.getString(6);
    
         if (row[2] < 10)
         row[2] = "0"+row[2];
        if (row[4] < 10)
         row[4] = "0"+row[4];

        if (row[1] > 12)
        {
            t_noon_1 = " PM"; 
            row[1] = row[1] - 12;
        }
        if (row[3] > 12)
        {
            t_noon_2 = " PM"; 
            row[3] = row[3] - 12;
        }
        if (row[3] == 0)
            row[3] = 12;
        if (row[1] == 0)
            row[1] = 12;
        
     text (row[1] + ":" + row[2]+ t_noon_1 + " - " + row[3] + ":" + row[4] + t_noon_2 + "\n" + row[5] + "\n" + row[6], 1000, 30); 
    
     
}

function draw_news()
{
    let data;
    let i = 0;
    let rows = news.getRowCount();
    textSize(20); 
    fill(255,255,255);
    for (let r = 0; r < rows; r++)
        if (news.getNum(r,0) == day())
         
     {
            data = news.getString(r,1);
            text(data, 20, 480 + i*30);
            i++;
     } 
}

function draw_social()
{
    let twit = 0;
    let inst = 0;
    let face = 0;
    let diam = 40;
    let rows = social.getRowCount();
    textSize(20); 
    fill(255,255,255);
    for (let r = 0; r < rows; r++)
    {
        if (social.getString(r,0) == "twitter")
            twit++;
    else if (social.getString(r,0) == "facebook")
            face++;
    else if (social.getString(r,0) == "instagram")
            inst++;
    }
         
    text(inst + " notifications", 1050, 255);
    text(twit + " notifications", 1050, 300);
    text( face + " notifications", 1050, 345);
    image(instagram, 1000, 230, diam, diam);
    image(twitter, 1000, 275, diam, diam);
    image(facebook, 1000, 320, diam, diam);
        
}


function draw_messages()
{
    let rows = messages.getRowCount();
    textSize(20); 
    fill(255,255,255);
    text("Messages: " + rows + " new", 1000, 200);
               
}




function draw_weath_icon()
{
   let icon;
    let rows = weather.getRowCount();
    for (let r = 0; r < rows; r++)
        if (weather.getNum(r,0) == month() &&  weather.getNum(r,1) == day() && ((weather.getNum(r,2) - hour()) < 3 && (weather.getNum(r,2) - hour() > -4))) 
         
     {
            icon = weather.getNum(r,4);
            break;
     } 
    noStroke();
    let diam = 22;
    //icon = 4;
    switch (icon){
        case 0:
            image(weath_part_cloud, 1000, 520, diam-2, diam-2);
            break;
         case 1:
            image(weath_cloud, 1000, 520, diam-2, diam-2);
            break;
        case 2:
            fill (255, 240, 0);
            circle(1010, 528, diam);
            break;
        case 3:
            image(weath_rain, 1000, 520, diam-2, diam-2);
            break;    
        case 4:
            image(weath_night, 1000, 520, diam-2, diam-2);
            break;    
        }

}

function get_temp()
{
    let ret;
    let rows = weather.getRowCount();
    for (let r = 0; r < rows; r++)
        if (weather.getNum(r,0) == month() &&  weather.getNum(r,1) == day() && ((weather.getNum(r,2) - hour()) < 3 && (weather.getNum(r,2) - hour() > -4))) 
         
     {
            ret = weather.getNum(r,3);
            break;
     }
    
        
    
    return(ret);
}


function mouseClicked()
{
    if (event == 0)
    {
    if (mouseX > 1000 && mouseX < 1170 && mouseY > 180 && mouseY < 205)
    event = 1; // message
    else if (mouseX > 1000 && mouseX < 1170 && mouseY > 225 && mouseY < 355)
    event = 2; // social
    else if (mouseX > 1000 && mouseX < 1170 && mouseY > 5 && mouseY < 85)
    event = 3;// calendar
    }

    else if ((event == 1 || event == 2 || event == 3) && (mouseX > 1158 && mouseX < 1200 && mouseY > 0 && mouseY < 43)) 
        event = 0;
        
}

function openMessage()
{
    fill(29,35, 22);
    rect (800, 0, 400, 550);
    image(clos, 1160, 0, 40, 40);
    
    fill(255, 255, 255);
    let rows = messages.getRowCount();
    
    for (let r = 0; r < rows; r++) 
    {
        textSize(30);
        text (messages.getString(r,0), 820, 40 + 50*r);
        textSize(15);
        text (messages.getString(r,1), 940, 35 + 50*r);
        
    }
    
     
    
   // text("Messages: " + rows + " new", 1000, 200);
}

function openSocial()
{
    fill(29,35, 22);
    rect (800, 0, 400, 550);
    image(clos, 1160, 0, 40, 40);
    fill(255, 255, 255);
    let rows = social.getRowCount();
    
    for (let r = 0; r < rows; r++) 
    {
        textSize(30);
        text (social.getString(r,0), 820, 40 + 50*r);
        textSize(15);
        text (social.getString(r,1), 970, 35 + 50*r);
        
    }
}

function openCalendar()
{
    fill(29,35, 22);
    rect (800, 0, 400, 550);
    image(clos, 1160, 0, 40, 40);
    fill(255, 255, 255);
    
    for (let r = cal_day; r < cal_day+8; r++) 
    {
        
        textSize(13);
        text ("November, " + calendar.getNum(r,0), 820, 40 + 50*r);
        
        text (calendar.getNum(r,1) + ":" + calendar.getNum(r,2) + "-" + calendar.getNum(r,3) + ":" + calendar.getNum(r,4), 930, 40 + 50*r);
        text (calendar.getString(r,5), 1020, 40 + 50*r);
        text (calendar.getString(r,6), 1100, 40 + 50*r); 
        
    }
        
    
    
}





